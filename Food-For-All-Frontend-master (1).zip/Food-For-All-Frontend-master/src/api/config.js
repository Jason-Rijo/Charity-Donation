// Export base url
export const API_URL = 'http://localhost:8070';